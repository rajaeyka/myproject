from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from .models import Task
from .forms import TaskForm
from django.contrib.auth.models import User


def loginPage(request):
    page='login'
    if request.user.is_authenticated:
        return redirect('home')

    if request.method =='POST':
        username = request.POST.get('username').lower()
        password = request.POST.get('password')

        try:
            user=User.objects.get(username=username)
        except:
            messages.error(request, 'User does not exist')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Username OR password does not exist')


    context = {'page':page}
    return render(request, 'base/login_register.html', context)

def logoutUser(request):
    logout(request)
    return redirect('home')

def registerPage(request):
    form = UserCreationForm()

    if request.method =='POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.username = user.username.lower()
            user.save()
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'An error occured during registration')

    return render(request, 'base/login_register.html', {'form':form})

def home(request):
    tasks = Task.objects.all()
    context = {'tasks':tasks}
    return render(request, 'base/home.html', context)

def task(request,pk):
    task = Task.objects.get(id=pk)
    context = {'task': task}
    return render(request, 'base/task.html', context)

def userProfile(request, pk):
    user = User.objects.get(id=pk)
    tasks = user.task_set.all()
    context = {'user': user, 'tasks': tasks}
    return render(request, 'base/profile.html', context)

@login_required(login_url='login')
def createTask(request):
    form = TaskForm()
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
           task = form.save(commit=False)
           task.user = request.user
           task.save()
           return redirect('home')

    context = {'form': form}
    return render(request, 'base/task_form.html', context)

@login_required(login_url='login')
def updateTask(request, pk):
    task = Task.objects.get(id=pk)
    form = TaskForm(instance=task)

    if request.user != task.user:
        return HttpResponse('Youre not allowed here!!')

    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('home')
    context = {'form': form}
    return render(request, 'base/task_form.html', context)

@login_required(login_url='login')
def deleteTask(request, pk):
    task = Task.objects.get(id=pk)

    if request.user != task.user:
        return HttpResponse('Youre not allowed here!!')


    if request.method == 'POST':
        task.delete()
        return redirect('home')
    return render(request, 'base/delete.html', {'obj': task})


@login_required(login_url='login')
def updateUser(request):
    return render(request, 'base/update-user.html')